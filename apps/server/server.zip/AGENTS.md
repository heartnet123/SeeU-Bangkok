# AGENTS.md — apps/server

> Hono API on Bun + Multi-Agent Supervisor (v2) + Supabase

**Parent:** `../../AGENTS.md`

## STRUCTURE

```
src/
├── index.ts          # Entry (CORS, logger, /scalar docs)
├── routers/
│   ├── agent-v2.ts   # Multi-Agent Supervisor v2 (chat endpoint)
│   ├── auth.ts, places.ts, tools.ts, itineraries.ts, admin.ts
├── agent/            # Multi-Agent Module (NEW)
│   ├── index.ts      # Main exports
│   ├── state.ts      # AgentState schema (Zod)
│   ├── supervisor.ts # Supervisor orchestrator
│   ├── streaming.ts  # SSE streaming adapter
│   ├── agents/       # Specialized agents
│   │   ├── researcher.ts  # Search & semantic retrieval
│   │   ├── planner.ts     # Route optimization & itineraries
│   │   └── critic.ts      # Validation & QA
│   ├── tools/        # LangGraph-compatible tools
│   │   ├── search.ts      # search_places, nearby_places
│   │   ├── retrieval.ts   # vector_search
│   │   ├── planning.ts    # build_route, plan_itinerary
│   │   └── validation.ts  # validate_itinerary
│   └── memory/       # Session & long-term memory
│       ├── session.ts     # Conversation sessions
│       └── longterm.ts    # User preferences
├── middleware/       # auth.ts (JWT), internal.ts (API key)
├── lib/              # openai.ts, tools.ts, supabase.ts
└── db/               # Drizzle (migrations only)

sql/
└── agent_memory_tables.sql  # Memory tables migration
```

## COMMANDS

| Task | Command |
|------|---------|
| Dev | `bun run dev:server` |
| Build | `bun run build` (tsdown) |
| Binary | `bun run compile` |
| Apply memory migration | Run `sql/agent_memory_tables.sql` in Supabase |

## MULTI-AGENT ARCHITECTURE (v2)

### Agents
| Agent | Role | Tools |
|-------|------|-------|
| `researcher_agent` | Find places, semantic search | `search_places`, `nearby_places`, `vector_search` |
| `planner_agent` | Route optimization, itineraries | `build_route`, `plan_itinerary` |
| `critic_agent` | Validation, quality assurance | `validate_itinerary` |

### Supervisor Flow
```
User Message → Supervisor → [researcher → planner] → critic (only when validation/revision is needed) → Response
```
The supervisor dynamically routes to agents based on user intent.

### API Endpoints
- `POST /api/agent/v2` - New multi-agent supervisor
- `GET /api/agent/v2/health` - Health check
- `GET /api/agent/v2/agents` - List agents

### SSE Events (v2)
`start`, `agent`, `tools`, `context`, `suggestions`, `itinerary`, `message`, `error`, `done`

### AgentState (v2)
```typescript
interface AgentState {
  messages, userLocation?, sessionId?, userId?,
  currentAgent?, agentHistory, toolCalls, retrievedDocs,
  context, itinerary?, finalResponse?, error?, userPreferences
}
```

## CONVENTIONS

### Router Pattern
```typescript
router.post("/endpoint",
  zValidator("json", z.object({ field: z.string() })),
  async (c) => c.json({ success: true, data: {...} })
);
```

### Response: `{ success: true/false, data/error }`

### LangSmith Tracing
```typescript
const fn = traceable(async (args) => {...}, { name: "tools.my_function" });
```

## ANTI-PATTERNS

| Forbidden | Reason |
|-----------|--------|
| Raw SQL | Use Supabase SDK |
| No zValidator | Always validate |
| Type assertions `as any` | Use explicit types (except bun module workarounds) |

## WHERE TO LOOK

| Task | Location |
|------|----------|
| Add endpoint | `src/routers/` |
| Add AI tool | `src/agent/tools/` + register in tools/index.ts |
| Add new agent | `src/agent/agents/` |
| Modify supervisor | `src/agent/supervisor.ts` |
| Modify v2 RAG | `src/routers/agent-v2.ts` (carefully) |
| Auth | `src/middleware/auth.ts` |
| DB queries | `src/lib/supabase.ts` (not Drizzle) |
| Memory management | `src/agent/memory/` |
