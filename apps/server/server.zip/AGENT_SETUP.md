# RAG Agent Setup Guide

## Overview

The RAG (Retrieval-Augmented Generation) agent uses LangGraph workflow with vector search, tool calling, and context-aware response generation.

## Current Status ✅

- **Vector Search**: Working! Successfully retrieving documents from Supabase
- **Tool System**: Working! Tools are being called correctly
- **Frontend Integration**: Working! UI shows tools used and context retrieved

## What Changed (agent.ts)

- Orchestration: LangGraph `StateGraph` with nodes `analyze → retrieve → generate` and delta streaming.
- Vector search: RPC `match_places` with fallback when `similarity_threshold` arg isn't available; client-side filter `minSimilarity = 0.35`.
- SSE events during streaming:
  - `start` – processing started
  - `tools` – planned tool calls with args
  - `context` – `{ documents, top_docs }` summary
  - `message` – final response from LLM
  - `error` – error details (if any)
  - `done` – stream complete
- Tools available: `vector_search`, `nearby_places`, `search_places`, `build_route`.

## Known Issue: "blob error"

This error occurs during LLM text generation, likely due to:

1. Hugging Face API rate limits or timeouts
2. Model availability issues
3. Token limits exceeded

### Solution Options:

#### Option 1: Use OpenAI instead of Hugging Face (Recommended)

The project already has OpenAI installed. Update the agent to use OpenAI:

1. Add OpenAI API key to `.env`:

```env
OPENAI_API_KEY=your-key-here
```

2. Update `/apps/server/src/routers/agent.ts` - Replace the `hfGenerateText` call in the `generate()` function with OpenAI:

```typescript
import OpenAI from 'openai'

// At the top of the file
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

// In the generate() function, replace:
const response = await hfGenerateText(userPrompt, {...})

// With:
const completion = await openai.chat.completions.create({
  model: 'gpt-3.5-turbo',
  messages: [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt }
  ],
  max_tokens: 300,
  temperature: 0.7,
})
const response = completion.choices[0]?.message?.content || 'No response generated'
```

#### Option 2: Improve Hugging Face Error Handling

The code already has fallback logic, but we can improve it:

```typescript
// In generate() function
try {
  const response = await hfGenerateText(userPrompt, {
    system: systemPrompt,
    max_new_tokens: 300,
    temperature: 0.7,
    retries: 3, // Increase retries
    timeout_ms: 30000, // Increase timeout
  });
  // ... rest of code
} catch (err: any) {
  // Fallback to a simpler response using just the context
  const simpleResponse = `Based on your query, I found ${
    state.retrievedDocs.length
  } relevant places: ${state.retrievedDocs
    .slice(0, 3)
    .map((d) => d.metadata.name)
    .join(", ")}. ${toolResults}`;

  return {
    finalResponse: simpleResponse,
    currentStep: "complete",
    messages: [
      ...state.messages,
      { role: "assistant", content: simpleResponse },
    ],
  };
}
```

#### Option 3: Check Database Setup

Ensure your Supabase database has:

1. **Vector extension enabled**:

```sql
create extension if not exists vector;
```

2. **Embedding column** in `bangkok_unseen` table:

```sql
ALTER TABLE bangkok_unseen ADD COLUMN IF NOT EXISTS embedding vector(1536);
```

3. **Vector index** for performance:

```sql
CREATE INDEX ON bangkok_unseen USING ivfflat (embedding vector_cosine_ops);
```

4. **The `match_places` function** (already in `/apps/server/sql/match_places.sql`):

Run this SQL in your Supabase SQL editor:

```sql
-- Copy the entire content from apps/server/sql/match_places.sql
```

### Option 4: Tune Vector Search Threshold

The agent filters results with `minSimilarity = 0.35`. To increase precision, raise this value (e.g., `0.45`); to increase recall, lower it (e.g., `0.30`). Ensure your data distribution supports the chosen threshold.

## Testing the Agent

### 1. Test Vector Search Only

```bash
curl -X POST http://localhost:3000/api/agent \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [{"role": "user", "content": "temples"}],
    "stream": false
  }'
```

### 2. Test Streaming (SSE) Quickly

Note: `curl` won't parse SSE, but you can observe raw event stream:

```bash
curl -N -X POST http://localhost:3000/api/agent \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [{"role": "user", "content": "temples near me"}],
    "userLocation": {"lat": 13.7563, "lng": 100.5018},
    "stream": true
  }'
```

Expected order: `start` → `tools` → `context` → `message` → `done` (and `error` if any).

### 3. Test with Frontend

1. Navigate to `/chat`
2. Click "🤖 RAG Agent" button
3. Enter query: "Show me temples"
4. You should see:
   - ✅ Tools Used: vector_search
   - ✅ Retrieved Context: X documents retrieved
   - ❌ Response: "blob error" (if using HF)

### 4. Verify Vector Search Directly

```bash
# In Supabase SQL Editor
SELECT name, description
FROM bangkok_unseen
WHERE embedding IS NOT NULL
LIMIT 5;
```

## Current Working Features ✅

1. **Vector Search**: Embeddings are generated and searched successfully
2. **Tool Calling**: Agent correctly identifies which tools to use
3. **Context Retrieval**: Documents are retrieved from vector database
4. **Frontend Display**: UI shows the agent's reasoning process
5. **Classic Chat**: Still works as fallback

## Quick Fix for Immediate Use

Since vector search IS working, you can use "Classic Chat" mode for now, which uses the same retrieval but with simpler text generation that's already proven to work.

## Environment Variables Needed

```env
# Required
SUPABASE_URL=your-supabase-url
SUPABASE_ANON_KEY=your-anon-key
HF_TOKEN=your-huggingface-token

# Optional but recommended for agent
OPENAI_API_KEY=your-openai-key

# Optional
CORS_ORIGIN=http://localhost:3001
NEXT_PUBLIC_SERVER_URL=http://localhost:3000
```

## Troubleshooting

### Issue: "Could not find function match_places"

**Solution**: Run the SQL from `apps/server/sql/match_places.sql` in Supabase SQL Editor

### Issue: "Vector search failed" but tools show success

**Solution**: The retrieval is working! Only the final text generation failed. Use Option 1 (OpenAI) above.

### Issue: No documents retrieved

**Solution**:

1. Check if `embedding` column has data: `SELECT COUNT(*) FROM bangkok_unseen WHERE embedding IS NOT NULL;`
2. Generate embeddings for your places if needed

### Issue: Frontend shows "blob error"

**Solution**: This is from HF API, not your code. The vector search and tools are working correctly!

### Issue: RPC `similarity_threshold` not recognized

**Solution**: The agent auto-falls back to the older RPC signature. For best results, apply `apps/server/sql/match_places.sql` which includes the parameter.

## Next Steps

1. **Immediate**: Switch to OpenAI for text generation (Option 1)
2. **Later**: Generate embeddings for all places in database
3. **Optional**: Add more sophisticated tools and agents

## Success Indicators

You've already achieved:

- ✅ Vector similarity search working
- ✅ Tool system functioning
- ✅ Frontend integration complete
- ✅ Transparent agent reasoning displayed

Only missing:

- ❌ Stable LLM text generation (fixable with OpenAI)
